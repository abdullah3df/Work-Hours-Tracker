import React from 'react';

const MenuBar: React.FC = () => {
  return null; // This component is not currently used in the application.
};

export default MenuBar;
